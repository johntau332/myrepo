import { useState,useEffect } from "react";

const Tabul : React.FC = ()=>{

   const [d,setData] = useState({});

  useEffect(() => {
    fetch("https://reqres.in/api/users", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": "reqres-free-v1",
      }
    })
      .then((res) => res.json())
      .then((ans) => setData(ans))
      .catch((err) => {
        console.log(err);
      });
  },[]);
  console.log(d);

    return (
        <>
        <div>
            <table border={1}>
          <thead>
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Email</th>
              <th>Page</th>
              <th>Total Pages</th>
            </tr>
          </thead>
          <tbody>
            {d.data?.map((v: any) => (
              <tr key={v.id}>
                <td>{v.id}</td>
                <td>{v.first_name} {v.last_name}</td>
                <td>{v.email}</td>
                <td>{d.page}</td>
                <td>{d.total_pages}</td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
        
        </>
    )
}
export default Tabul;