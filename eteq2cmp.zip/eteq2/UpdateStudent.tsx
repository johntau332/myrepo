import { useLocation, useNavigate } from "react-router-dom";
import { useState } from "react";
import { Details } from "./Studentdetails";

const UpdateStudent: React.FC = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const [student, setStudent] = useState<Details>(state.student);
  const index = state.index;

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    const storedData = JSON.parse(localStorage.getItem("students") || "[]");
    storedData[index] = student;
    localStorage.setItem("students", JSON.stringify(storedData));
    navigate("/");
  };

  return (
    <form onSubmit={handleUpdate}>
      <div>
        <label>Id:</label>
        <input
          type="text"
          value={student.id}
          onChange={(e) => setStudent({ ...student, id: e.target.value })}
        />
      </div>

      <div>
        <label>Name:</label>
        <input
          type="text"
          value={student.name}
          onChange={(e) => setStudent({ ...student, name: e.target.value })}
        />
      </div>

      <div>
        <label>Email:</label>
        <input
          type="text"
          value={student.email}
          onChange={(e) => setStudent({ ...student, email: e.target.value })}
        />
      </div>

      <div>
        <label>CGPA:</label>
        <input
          type="text"
          value={student.cgpa}
          onChange={(e) => setStudent({ ...student, cgpa: e.target.value })}
        />
      </div>

      <button type="submit">Save Changes</button>
    </form>
  );
};

export default UpdateStudent;
