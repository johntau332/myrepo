import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function SearchPage() {
  const [query, setQuery] = useState("");
  const [lastSearchedMovie, setLastSearchedMovie] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleSearch = () => {
    if (query.trim()) {
      setLastSearchedMovie(query);
      navigate(`/movie/${query}`);
    }
  };

  const handleBackToMovie = () => {
    if (lastSearchedMovie) {
      navigate(`/movie/${lastSearchedMovie}`);
    } else {
      navigate("/movie/Breaking Bad"); 
    }
  };

  return (
    <div className="flex flex-col items-center p-4">
      <h1 className="text-2xl font-bold mb-4">Movie Search</h1>
      <input
        type="text"
        placeholder="Enter movie title"
        className="border p-2 rounded w-64"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <div className="mt-2">
        <button className="bg-blue-500 text-white p-2 rounded mr-2" onClick={handleSearch}>
          Search
        </button>
        <button className="bg-gray-500 text-white p-2 rounded" onClick={handleBackToMovie}>
          Back to Movie Page
        </button>
      </div>
    </div>
  );
}

export default SearchPage;
