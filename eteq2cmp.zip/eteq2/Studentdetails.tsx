import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

export type Details = {
  id: string;
  name: string;
  email: string;
  cgpa: string | number;
};

const Studentdetails: React.FC = () => {
  const [stu, setStu] = useState<Details>({
    id: "",
    name: "",
    email: "",
    cgpa: "",
  });

  const [students, setStudents] = useState<Details[]>([]);
  const [showDetails, setShowDetails] = useState(false);

  const navigate = useNavigate();

  // 👉 Load students from localStorage on component mount
  useEffect(() => {
    const storedStudents = JSON.parse(localStorage.getItem("students") || "[]");
    setStudents(storedStudents);
    if (storedStudents.length > 0) setShowDetails(true);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (stu.id !== "") {
      const updatedList = [...students, stu];
      setStudents(updatedList);
      setShowDetails(true);

      // 👉 Store the updated list in localStorage
      localStorage.setItem("students", JSON.stringify(updatedList));

      // Clear the form
      setStu({
        id: "",
        name: "",
        email: "",
        cgpa: "",
      });
    }
  };

  const handleDelete = (index: number) => {
    const updatedList = students.filter((_, i) => i !== index);
    setStudents(updatedList);
    localStorage.setItem("students", JSON.stringify(updatedList));
  };

  const handleUpdate = (index: number) => {
    navigate("/update-student", { state: { student: students[index], index } });
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Id:</label>
          <input
            type="text"
            value={stu.id}
            onChange={(e) => setStu((prev) => ({ ...prev, id: e.target.value }))}
          />
        </div>

        <div>
          <label>Name:</label>
          <input
            type="text"
            value={stu.name}
            onChange={(e) =>
              setStu((prev) => ({ ...prev, name: e.target.value }))
            }
          />
        </div>

        <div>
          <label>Email:</label>
          <input
            type="text"
            value={stu.email}
            onChange={(e) =>
              setStu((prev) => ({ ...prev, email: e.target.value }))
            }
          />
        </div>

        <div>
          <label>CGPA:</label>
          <input
            type="text"
            value={stu.cgpa}
            onChange={(e) =>
              setStu((prev) => ({ ...prev, cgpa: e.target.value }))
            }
          />
        </div>

        <button type="submit">Submit</button>
      </form>

      {showDetails && students.length > 0 && (
        <div>
          <h3>Student Details:</h3>
          {students.map((student, index) => (
            <div
              key={index}
              style={{
                marginBottom: "10px",
                border: "1px solid #ccc",
                padding: "5px",
              }}
            >
              <p>
                <strong>Id:</strong> {student.id}
              </p>
              <p>
                <strong>Name:</strong> {student.name}
              </p>
              <p>
                <strong>Email:</strong> {student.email}
              </p>
              <p>
                <strong>CGPA:</strong> {student.cgpa}
              </p>
              <button onClick={() => handleUpdate(index)}>Update</button>
              <button onClick={() => handleDelete(index)}>Delete</button>
            </div>
          ))}
        </div>
      )}
    </>
  );
};

export default Studentdetails;
