import React, { useContext, useState } from 'react'
import { AuthContext } from './contexts/AuthContext'

const Login = () => {
    const[username,setUsername]=useState('');
    const{user,login,logout}=useContext(AuthContext)
  return (
    <div>
        {
            user?(
                <div>
                    <h2>{username}, you have logged in successfully</h2>
                    <button className='m-2 border border-black' onClick={logout}>Logout</button>
                </div>
            ):(
                <div>
                    <input type="text" className='m-2 border border-black' onChange={(e)=>{setUsername(e.target.value)}} />
                    <button className='m-2 border border-black' onClick={()=>login(username)}>Login</button>
                </div>
            )
        }
    </div>
  )
}

export default Login