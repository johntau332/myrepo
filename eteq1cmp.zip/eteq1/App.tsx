import React from "react";
import Todo from "./Todo";
import Tabul from "./Tabul";
import Dropdown from "./Dropdown";
import Stopwatch from "./Stopwatch";
import Studentdetails from "./Studentdetails";
import { BrowserRouter, Route,Routes } from "react-router-dom";
import UpdateStudent from "./UpdateStudent";
const App: React.FC = () => {
  return (
    <>
      {/* <Todo/> */}
      {/* <Tabul/> */}
      {/* <Dropdown/> */}
      {/* <Stopwatch/> */}
      
      <Routes>
        <Route path="/" element={<Studentdetails />} />
        <Route path="/update-student" element={<UpdateStudent />} />
      </Routes>
    
    </>
  );
};

export default App;
