import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

const API_KEY = "ecb969c6";
const API_URL = "https://www.omdbapi.com/";

function MoviePage() {
  const { title } = useParams();
  const navigate = useNavigate();
  const [movie, setMovie] = useState<any>(null);

  useEffect(() => {
    fetch(`${API_URL}?t=${title}&apikey=${API_KEY}`)
      .then((res) => res.json())
      .then((data) => setMovie(data))
      .catch((err) => console.error("Error fetching data:", err));
  }, [title]);

  if (!movie || movie.Response === "False") return <h2>Movie not found</h2>;

  return (
    <div className="flex flex-col items-center p-4">
      <h1 className="text-2xl font-bold">{movie.Title}</h1>
      {movie.Poster && <img src={movie.Poster} alt={movie.Title} className="mt-2 w-64 h-auto" />}
      <p>Release Date: {movie.Released}</p>
      <p>Rating: {movie.imdbRating}</p>

      <button
        className="bg-gray-500 text-white p-2 mt-4 rounded"
        onClick={() => navigate("/")}
      >
        Back to Search Page
      </button>
    </div>
  );
}

export default MoviePage;
