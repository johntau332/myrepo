import { useState } from "react";

const Stopwatch = () => {
  type Time = {
    hours: number;
    min: number;
    sec: number;
  };

  const [time, setTime] = useState<Time>({ hours: 0, min: 0, sec: 0 });
  const [intervalId, setIntervalId] = useState<number | null>(null);

  const startTime = () => {
    if (intervalId !== null) return;

    const id = window.setInterval(() => {
      setTime((prev) => {
        let { hours, min, sec } = prev;
        sec++;
        if (sec === 60) {
          sec = 0;
          min++;
        }
        if (min === 60) {
          min = 0;
          hours++;
        }
        return { hours, min, sec };
      });
    }, 1);

    setIntervalId(id);
  };

  const stopTime = () => {
    if (intervalId !== null) {
      clearInterval(intervalId);
      setIntervalId(null);
    }
  };

  const resetTime = () => {
    stopTime();
    setTime({ hours: 0, min: 0, sec: 0 });
  };

  return (
    <>
      <h3>Timer</h3>
      <p>
        {time.hours} Hours : {time.min} Minutes : {time.sec} Seconds
      </p>
      <div>
        <button onClick={startTime}>Start</button>
        <button onClick={stopTime}>Stop</button>
        <button onClick={resetTime}>Reset</button>
      </div>
    </>
  );
};

export default Stopwatch;
