import React, { useState } from 'react';

type Task = {
  text: string;
  completed: boolean;
};

const Todo: React.FC = () => {
  const [v, setv] = useState<string>('');
  const [arr, setarr] = useState<Task[]>([]);

  const create = () => {
    if (v.trim()) {
      setarr((prev) => [...prev, { text: v, completed: false }]);
      setv('');
    }
  };

  const complete = (i: number) => {
    setarr((prev) =>
      prev.map((task, index) =>
        index === i ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const deleted = (i: number) => {
    setarr((prev) => prev.filter((_, index) => index !== i));
  };

  return (
    <>
      <input
        type="text"
        placeholder="Enter the task"
        value={v}
        onChange={(e) => {
          setv(e.target.value);
        }}
      />
      <button onClick={create}>Add</button>

      <div>
        <ul>
          {arr.map((task, i) => (
            <li key={i} className={task.completed ? 'line-through' : ''}>
              {task.text}
              <button onClick={() => complete(i)}>
                {task.completed ? 'completed' : 'incompleted'}
              </button>
              <button onClick={() => deleted(i)}>Delete</button>
            </li>
          ))}
        </ul>
      </div>
    </>
  );
};

export default Todo;