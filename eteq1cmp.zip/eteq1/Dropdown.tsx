import { useState } from "react";

const Dropdown: React.FC = () => {
  const [message, setMessage] = useState<string>("");

  const arr = [
    "On Sunday we worship god Surya dev",
    "On Monday we worship god Shiva ji",
    "On Tuesday we worship god Hanuman ji",
    "On Wednesday we worship god Ganesh ji",
    "On Thursday we worship god Vanspati",
    "On Friday we worship god Laxmi ji and Vishnu ji",
    "On Saturday we worship god Shani Dev and Hanuman ji",
  ];

  return (
    <>
      <select
        name="choose-day"
        onChange={(e) => setMessage(arr[e.target.value])}
      >
        <option value="">Choose a day</option>
        <option value="0">Sunday</option>
        <option value="1">Monday</option>
        <option value="2">Tuesday</option>
        <option value="3">Wednesday</option>
        <option value="4">Thursday</option>
        <option value="5">Friday</option>
        <option value="6">Saturday</option>
      </select>

      <div className="mt-4">
        { <p>{message}</p>}
      </div>
    </>
  );
};

export default Dropdown;
